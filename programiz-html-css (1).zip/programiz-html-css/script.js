const listContainer = document.getElementById("list-container");
const inputBox = document.getElementById("input-box");

window.addTask = function () {
  const listContainer = document.getElementById("list-container");
  const inputBox = document.getElementById("input-box");
  if (inputBox.value === '') {
    alert("Enter Some Data");
  } else {
    let li = document.createElement("li");
    li.innerHTML = inputBox.value;
    listContainer.appendChild(li);

    let span = document.createElement("span");
    span.innerHTML = "\u00d7"; // Unicode for ×
    li.appendChild(span);

    console.log("Task to be added:", inputBox.value);
  }
  inputBox.value = "";
  saveTask();
};

listContainer.addEventListener("click", function (e){
  console.log('Clicked element:', e.target.tagName);
  if (e.target.tagName === "LI") {
    e.target.classList.toggle("checked");
    saveTask();
  }else if (e.target.tagName === "SPAN"){
    e.target.parentElement.remove();
    saveTask();
    
  }
});

function saveTask() {
  localStorage.setItem("data", listContainer.innerHTML);
  console.log("Tasks saved to localStorage:", listContainer.innerHTML);
}

function showTask() {
  const savedTasks = localStorage.getItem("data");
  listContainer.innerHTML = savedTasks;
  console.log("Loaded tasks from localStorage:", savedTasks);
}

showTask();
